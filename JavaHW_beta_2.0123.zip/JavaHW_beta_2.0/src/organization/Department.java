package organization;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class Department {
    protected String unit;
    public ArrayList<Employee> EmployeeArr;
    public Employee[] EmployeeArray;
    public Department(String unit, ArrayList<Employee> EmployeeArr) {
        this.unit = unit;
        this.EmployeeArr = EmployeeArr;
    }

    public String Get_Unit() {
        return unit;
    }

    protected void Set_Unit(String ReUnit) {
        unit = ReUnit;
    }

    public int Unit_Size() {
        return EmployeeArr.size();
    }

    public int Unit_Salary() {
        int unit_salary = 0;
        for (int i = 0; i < EmployeeArr.size(); i++) {
            unit_salary += (EmployeeArr.get(i).Get_Salary());
        }
        return unit_salary;
    }

    public Employee Index_Employee(String Name, String Surname) {
        int index = -1;
        if (EmployeeArr.size() == 0) {
            System.out.println("Empty list of employee");
        } else {
            for (int i = 0; i < EmployeeArr.size(); i++) {
                if (EmployeeArr.get(i).Get_Name() == Name && EmployeeArr.get(i).Get_Surname() == Surname) {
                    index = i;
                }
            }
            if (index == -1) {
                System.out.println("Not Found");
            }
        }
        return EmployeeArr.get(index);
    }

    protected void Discharge(String Name, String Surname, String Position) {
        for (int i = 0; i < EmployeeArr.size(); i++) {
            if (((EmployeeArr.get(i)).Get_Name() == Name) && ((EmployeeArr.get(i)).Get_Surname() == Surname) && ((EmployeeArr.get(i)).Get_Position() == Position)) {
                EmployeeArr.remove(i);
            }
        }


    }

    public void Hiring(Employee HiringEmployee) {
        EmployeeArr.add(HiringEmployee);
    }

    public void /*ArrayList*/ Return_Employee_List(/*ArrayList<Employee> EmployeeArr*/) {
        // Вывод списка в консоль
        for (int i = 0; i < EmployeeArr.size(); i++) {
            System.out.println("Name:" + EmployeeArr.get(i).Get_Name() + ";" + " " + "Surname:" + EmployeeArr.get(i).Get_Surname() + ";" + " " + "Position:" + EmployeeArr.get(i).Get_Position() + ";" + " " + "Salary:" + EmployeeArr.get(i).Get_Salary() + ";");
        }
        // Вывод ссылки на список
        /*return EmployeeArr */;
    }

    public void /*ArrayList<Employee>*/ SortEmployeeList() {
        Employee[] Sorted_Employee_Array = new Employee[EmployeeArr.size()];
        for (int i = 0; i < EmployeeArr.size(); i++) {
            Sorted_Employee_Array[i] = EmployeeArr.get(i);
        }
        ArrayList<Employee> Sorted_Employee_Arr = new ArrayList<Employee>(EmployeeArr.size());
        Arrays.sort(Sorted_Employee_Array, new Comparator<Employee>() {
            public int compare(Employee first_employee, Employee next_employee){
                if(first_employee.Get_Name().equals(next_employee.Get_Name())){
                    return first_employee.Get_Name().compareTo(next_employee.Get_Name());
                }
                return first_employee.Get_Surname().compareTo(next_employee.Get_Surname());
            }
        });
        // Вывод в консоль
        for (int i = 0; i < Sorted_Employee_Array.length; i++) {
            Sorted_Employee_Arr.add(Sorted_Employee_Array[i]);
            System.out.println("Name:" + Sorted_Employee_Arr.get(i).Get_Name() + ";" + " " + "Surname:" + Sorted_Employee_Arr.get(i).Get_Surname() + ";" + " " + "Position:" + Sorted_Employee_Arr.get(i).Get_Position() + ";" + " " + "Salary:" + Sorted_Employee_Arr.get(i).Get_Salary() + ";");
        }
        // Вывод ссылки на отсортированный список
                /*return Sorted_Employee_Arr;*/

    }
}
