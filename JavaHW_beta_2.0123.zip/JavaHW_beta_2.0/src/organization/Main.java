package organization;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        ArrayList<Employee> Staff = new ArrayList<>();
        Employee First = new Employee("Thomas", "Cormen", "algorithm engineering", 5000);
        Employee Second = new Employee("Stephen", "Prata", "C++ analysis", 7500);
        Employee Third = new Employee("Ben", "Forta", "SQL", 4000);
        Employee Fourth = new Employee("Ben", "Benis", "chill", 0);
        Staff.add(First);
        Staff.add(Second);
        Staff.add(Third);
        Staff.add(Fourth);
        First.Set_Name("FunThomas");
        First.Set_Surname("Cormenius");
        First.Set_Position("algorithm with go to");
        First.Set_Salary(5051);
        System.out.println(First.Get_Name());
        System.out.println(First.Get_Surname());
        System.out.println(First.Get_Position());
        System.out.println(First.Get_Salary());
        Department Alpha = new Department ("A-team", Staff);
        Alpha.Set_Unit("B-team");
        System.out.println(Alpha.Get_Unit());
        System.out.println(Alpha.Unit_Size());
        System.out.println(Alpha.Unit_Salary());
        System.out.println(Alpha.Index_Employee("FunThomas", "Cormenius").Get_Position());
        Alpha.Discharge("Ben", "Forta", "SQL");
        System.out.println(Alpha.Unit_Size());
        Employee Fifth = new Employee("Jhin", "Kazama", "Head of security", 10000);
        Alpha.Hiring(Fifth);
        System.out.println(Alpha.Unit_Size());
        Alpha.Return_Employee_List(/*Staff*/);
        System.out.println(); // Перенос для разделения списков
        Alpha./*Return_Employee_List(Alpha.SortEmployeeList());*/SortEmployeeList();
    }
}
