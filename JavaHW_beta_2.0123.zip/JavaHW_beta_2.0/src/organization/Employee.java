package organization;

public class Employee {
        protected String position;
        protected String name;
        protected String surname;
        protected int salary;
        public Employee (String name, String surname, String position, int salary){
            this.name = name;
            this.surname = surname;
            this.position = position;
            this.salary = salary;
        }
        public String Get_Name(){
            return name;
        }
        protected void Set_Name(String ReName){
            name = ReName;
        }
        public String Get_Surname(){
            return surname;
        }
        protected void Set_Surname(String ReSurname){
            surname = ReSurname;
        }
        public String Get_Position(){
            return position;
        }
        public void Set_Position(String RePosition){
            position = RePosition;
        }
        protected void Set_Salary(int ReSalary){
            salary = ReSalary;
        }
        public int Get_Salary(){
            return salary;
        }
}
